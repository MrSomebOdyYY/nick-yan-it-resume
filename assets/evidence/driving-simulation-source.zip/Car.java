
public class Car {
	private String name;
	private double fuelConsumption;
	private int seats;
	private String fuelGrade;
	
	public Car(String carName, double consumption, int seatCount, String grade) {
		name = carName;
		fuelConsumption = consumption;
		seats = seatCount;
		fuelGrade = grade;		
	}
	
	public String getName() {
		return name;
	}
	
	public double getFuelConsumption() {
		return fuelConsumption;
	}
	
	public int getSeats() {
		return seats;
	}
	
	public String getFuelGrade() {
		return fuelGrade;
	}
	
	
}
