
public class GasStation {
    private String name;
    private double regularPrice;
    private double premiumPrice;

    public GasStation(String stationName, double regular, double premium) {
        name = stationName;
        regularPrice = regular;
        premiumPrice = premium;
    }

    public String getName() {
        return name;
    }

    public double getRegularPrice() {
        return regularPrice;
    }

    public double getPremiumPrice() {
        return premiumPrice;
    }
}