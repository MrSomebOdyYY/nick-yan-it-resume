import java.util.*;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class DrivingSimulation_Fall26_YanN {

	public static void main(String[] args) throws FileNotFoundException {
		Car[] cars = {
				new Car("2021 Subaru WRX STI", 12.8, 5, "Premium"), new Car("2021 Toyota Corolla LE", 7.1, 5, "Regular"), new Car("2021 Toyota RAV4 LE AWD", 7.9, 5, "Regular")
		};
		
		System.out.println("Available cars: ");
		
		for (int i = 0; i < cars.length; i++) {
			System.out.println((i + 1) + ". " + cars[i].getName());
		}
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Choose a car (1-3): ");
		int carChoice = scan.nextInt();
		
		while (carChoice < 1 || carChoice > 3) {
			System.out.print("Invalid choice. Please choose a car (1-3): ");
			carChoice = scan.nextInt();
		}
		
		Car selectedCar = cars[carChoice - 1];
		
		System.out.println("You selected: " + selectedCar.getName());
		
		City[] cities = {
				new City("Vancouver", "Canada"), new City("Surrey", "Canada"), new City("Abbotsford", "Canada")
		};
		
		System.out.println("Available cities: ");
		
		for (int i = 0; i < cities.length; i++) {
			System.out.println((i +1) + ". " + cities[i].getName());
		}
		
		System.out.println("Choose a starting city (1-3): ");
		int startChoice = scan.nextInt();
		
		while (startChoice < 1 || startChoice > cities.length) {
			System.out.print("Invalid choice. Choose a starting city (1-3): ");
			startChoice = scan.nextInt();
		}
		
		City startCity = cities[startChoice - 1];
		
		System.out.println("Starting city: " + startCity.getName() + ", " + startCity.getCountry());
		
		System.out.println("Choose a destination city (1-3): ");
		int endChoice = scan.nextInt();
		
		while (endChoice < 1 || endChoice > cities.length || endChoice == startChoice) {
			System.out.println("Invalid choice, enter 1-3 and choose a different destination: ");
			endChoice = scan.nextInt();
		}
		
		City endCity = cities[endChoice - 1];
		
		System.out.println("Route: " + startCity.getName() + " to " + endCity.getName());
		
		System.out.println("Enter travel distance in km: ");
		double distance = scan.nextDouble();
		
		while (distance <= 0) {
			System.out.println("Distance must be greater than 0, enter again: ");
			distance = scan.nextDouble();
		}
		
		double baseFuel = distance * selectedCar.getFuelConsumption() / 100;
		
		System.out.printf("Travel distance: %.2f km%n", distance);
		System.out.printf("Base fuel consumption: %.2f L%n", baseFuel);
		
		int maxPassengers = selectedCar.getSeats() - 1;
		
		System.out.println("Enter passenger excluding the driver (0-" + maxPassengers + "): ");
		int passengers = scan.nextInt();
		
		while (passengers < 0 || passengers > maxPassengers) {
			System.out.println("Invalid number, enter 0-" + maxPassengers + " passengers: ");
			passengers = scan.nextInt();
		}
		
		System.out.println("Passengers excluding the driver: " + passengers);
		
		double passengerFuel = calculatePassengerFuel(baseFuel, passengers);
		
		System.out.printf("Extra fuel for passengers: %.2f L%n", passengerFuel);
		System.out.printf("Fuel including passengers: %.2f L%n", baseFuel + passengerFuel);
		
		System.out.println("Weather options: ");
		System.out.println("1. Sunny");
		System.out.println("2. Rainy");
		System.out.println("3. Snowy");
		
		System.out.println("Choose weather (1-3): ");
		int weatherChoice = scan.nextInt();
		
		while (weatherChoice < 1 || weatherChoice > 3) {
			System.out.println("Invalid choice, choose weather again(1-3): ");
			weatherChoice = scan.nextInt();
		}
		
		String weather;
		
		if (weatherChoice == 1) {
			weather = "Sunny";
		}
		else if (weatherChoice == 2) {
			weather = "Rainy";
		}
		else {
			weather = "Snowy";
		}
		
		System.out.println("Selected weather: " + weather);
		
		double weatherFuel = calculateWeatherFuel(baseFuel, weatherChoice);
		
		System.out.printf("Extra fuel for weather: %.2f L%n", weatherFuel);
		
		double totalFuel = baseFuel + passengerFuel + weatherFuel;
		System.out.printf("Fuel including passengers and weather: %.2f L%n", totalFuel);
		
		System.out.println("Enter road conditions: ");
		System.out.println("1. Flat paved road");
		System.out.println("2. Uphill road");
		System.out.println("3. Rough road");
		System.out.println("4. Downhill road");
		
		System.out.println("Choose road condition: ");
		int roadChoice = scan.nextInt();
		
		while (roadChoice < 1 || roadChoice > 4) {
			System.out.println("Invalid Choice, choose road condition again: ");
			roadChoice = scan.nextInt();
		}
		
		String roadCondition;
		
		if (roadChoice == 1) {
			roadCondition = "Flat paved road";
		}
		else if (roadChoice == 2) {
			roadCondition = "Uphill road";
		}
		else if (roadChoice == 3) {
			roadCondition = "Rough road";
		}
		else {
			roadCondition = "Downhill road";
		}
		
		System.out.println("Selected road condition: " + roadCondition);
		
		double roadFuel = calculateRoadFuel(baseFuel, roadChoice);
		
		totalFuel = totalFuel + roadFuel;
		
		System.out.printf("Fuel adjustment for road: %+.2f L%n", roadFuel);
		System.out.printf("Fuel including passengers, weather and road: %.2f L%n", totalFuel);
		
		System.out.println("AC on or off(1 = on, 2 = off): ");
		int acChoice = scan.nextInt();
		
		while (acChoice < 1 || acChoice > 2) {
			System.out.println("Invalid choice, enter ac status again: ");
			acChoice = scan.nextInt();
		}
		
		boolean acOn = (acChoice == 1);
		
		double acFuel = calculateAcFuel(baseFuel, acOn);
		totalFuel = totalFuel + acFuel;
		
		System.out.println("AC on: " + acOn);
		System.out.printf("Extra fuel for AC: %.2f L%n", acFuel);
		System.out.printf("Fuel including all factors so far: %.2f L%n", totalFuel);
		
		System.out.println("Enter luggage weight in kg: ");
		double luggageWeight = scan.nextDouble();
		
		while (luggageWeight < 0 || !Double.isFinite(luggageWeight)) {
			System.out.println("Invalid weight, enter a valid weight: ");
			luggageWeight = scan.nextDouble();
		}
		
		double luggageFuel = calculateLuggageFuel(baseFuel, luggageWeight);
		totalFuel = totalFuel + luggageFuel;
		
		System.out.printf("Luggage weight: %.2f kg%n", luggageWeight);
		System.out.printf("Extra fuel for luggage: %.2f L%n", luggageFuel);
		System.out.printf("Fuel including all factors so far: %.2f L%n", totalFuel);
		
		Random random = new Random();
		
		int trafficLights = random.nextInt(6) + 5;
		double lightSpacing = distance / (trafficLights + 1);

		System.out.printf("Simulated spacing between traffic lights: %.2f km%n", lightSpacing);
		
		int redLight = 0;
		int yellowLight = 0;
		int greenLight = 0;
		
		System.out.println("Traffic lights: " + trafficLights);
		
		double trafficFuel = 0;
		
		for (int i = 1; i <= trafficLights; i++) {
			double lightPosition = i * lightSpacing;
			System.out.printf("Positions: %.2f km from the start%n", lightPosition);
			
			int signal = random.nextInt(3);
			
			if (signal == 0) {
				System.out.println("Light " + i + ": Red");
				redLight++;
				trafficFuel += 0.03;
				System.out.println("Extra fuel at this light: 0.03 L");
			}
			else if (signal == 1) {
				System.out.println("Light " + i + ": Yellow");
				yellowLight++;
				trafficFuel += 0.01;
				System.out.println("Extra fuel at this light: 0.01 L");
			}
			else {
				System.out.println("Light " + i + ": Green");
				greenLight++;
				System.out.println("Extra fuel at this light: 0.00 L");
			}
		}
		
		System.out.println("Red lights: " + redLight);
		System.out.println("Yellow lights: " + yellowLight);
		System.out.println("Green lights: " + greenLight);
		
		totalFuel += trafficFuel;
		
		System.out.printf("Extra fuel for traffic lights: %.2f L%n", trafficFuel);
		System.out.printf("Fuel including traffic lights: %.2f L%n", totalFuel);
		
		int stopSigns = random.nextInt(5) + 1;
		double stopFuel = 0;
		
		System.out.println("Stop signs: " + stopSigns);
		
		for (int i = 1; i <= stopSigns; i++) {
			stopFuel +=0.03;
			System.out.println("Stop sign " + i + ": Stop");
			System.out.println("Extra fuel at this stop: 0.03 L");
		}
		
		totalFuel += stopFuel;
		
		System.out.printf("Extra fuel for stop signs: %.2f L%n", stopFuel);
		System.out.printf("Fuel including traffic lights and stop signs: %.2f L%n", totalFuel);
		
		System.out.print("Enter your fuel budget in CAD: ");
		double budget = scan.nextDouble();

		while (budget <= 0 || !Double.isFinite(budget)) {
		    System.out.print("Invalid budget. Enter a finite amount greater than 0: ");
		    budget = scan.nextDouble();
		}

		System.out.printf("Fuel budget: CAD %.2f%n", budget);
		System.out.println("Required fuel grade: " + selectedCar.getFuelGrade());
		
		GasStation[] stations = new GasStation[3];

		for (int i = 0; i < stations.length; i++) {
		    scan.nextLine();

		    System.out.println("Gas station " + (i + 1));
		    System.out.print("Enter station name: ");
		    String stationName = scan.nextLine();

		    System.out.print("Enter Regular price in CAD/L: ");
		    double regularPrice = scan.nextDouble();

		    while (regularPrice <= 0 || !Double.isFinite(regularPrice)) {
		        System.out.print("Invalid price. Enter Regular price again: ");
		        regularPrice = scan.nextDouble();
		    }

		    System.out.print("Enter Premium price in CAD/L: ");
		    double premiumPrice = scan.nextDouble();

		    while (premiumPrice <= 0 || !Double.isFinite(premiumPrice)) {
		        System.out.print("Invalid price. Enter Premium price again: ");
		        premiumPrice = scan.nextDouble();
		    }

		    stations[i] = new GasStation(stationName, regularPrice, premiumPrice);
		}

		System.out.println("Three gas stations recorded.");
		
		int firstIndex = random.nextInt(stations.length);
		int secondIndex = random.nextInt(stations.length);

		while (secondIndex == firstIndex) {
		    secondIndex = random.nextInt(stations.length);
		}

		GasStation firstStation = stations[firstIndex];
		GasStation secondStation = stations[secondIndex];

		System.out.println("Selected gas stations:");

		System.out.println("1. " + firstStation.getName());
		System.out.printf("Regular: CAD %.3f/L%n", firstStation.getRegularPrice());
		System.out.printf("Premium: CAD %.3f/L%n", firstStation.getPremiumPrice());

		System.out.println("2. " + secondStation.getName());
		System.out.printf("Regular: CAD %.3f/L%n", secondStation.getRegularPrice());
		System.out.printf("Premium: CAD %.3f/L%n", secondStation.getPremiumPrice());
		
		double firstPrice;
		double secondPrice;

		if (selectedCar.getFuelGrade().equals("Premium")) {
		    firstPrice = firstStation.getPremiumPrice();
		    secondPrice = secondStation.getPremiumPrice();
		} else {
		    firstPrice = firstStation.getRegularPrice();
		    secondPrice = secondStation.getRegularPrice();
		}

		GasStation bestStation;
		double bestPrice;

		if (firstPrice <= secondPrice) {
		    bestStation = firstStation;
		    bestPrice = firstPrice;
		} else {
		    bestStation = secondStation;
		    bestPrice = secondPrice;
		}

		System.out.println("Selected fuel grade: " + selectedCar.getFuelGrade());

		if (firstPrice == secondPrice) {
		    System.out.println("Both stations have the same price for this grade.");
		}

		System.out.println("Best station for this grade among the two: " + bestStation.getName());
		System.out.printf("Selected price: CAD %.3f/L%n", bestPrice);
		
		double tripCost = totalFuel * bestPrice;
		double affordableFuel = budget / bestPrice;
		boolean budgetEnough = budget >= tripCost;

		System.out.printf("Total fuel needed: %.2f L%n", totalFuel);
		System.out.printf("Estimated trip cost: CAD %.2f%n", tripCost);
		System.out.printf("Fuel affordable with your budget: %.2f L%n", affordableFuel);

		if (budgetEnough) {
		    double remainingBudget = budget - tripCost;
		    System.out.println("Your budget is sufficient for this trip.");
		    System.out.printf("Remaining budget: CAD %.2f%n", remainingBudget);
		} else {
		    double shortfall = tripCost - budget;
		    System.out.println("Your budget is insufficient for this trip.");
		    System.out.printf("Additional money needed: CAD %.2f%n", shortfall);
		}
		
		PrintWriter report = new PrintWriter("ConsumptionReport_YanN.txt");

		report.println("Driving Simulation Report");
		report.println("Car: " + selectedCar.getName());
		report.println("Start: " + startCity.getName() + ", "
		        + startCity.getCountry());
		report.println("Destination: " + endCity.getName() + ", "
		        + endCity.getCountry());
		report.printf("Distance: %.2f km%n", distance);
		report.println();
		report.println("Trip conditions");
		report.println("Passengers excluding driver: " + passengers);
		report.println("Weather: " + weather);
		report.println("Road condition: " + roadCondition);
		report.println("AC on: " + acOn);
		report.printf("Luggage weight: %.2f kg%n", luggageWeight);
		report.println("Traffic lights: " + trafficLights);
		report.println("Red lights: " + redLight);
		report.println("Yellow lights: " + yellowLight);
		report.println("Green lights: " + greenLight);
		report.println("Stop signs: " + stopSigns);
		report.printf("Simulated light spacing: %.2f km%n", lightSpacing);
		report.println();
		report.println();
		report.println();
		report.println("Fuel breakdown");
		report.printf("Base fuel: %.3f L%n", baseFuel);
		report.printf("Passenger adjustment: %.3f L%n", passengerFuel);
		report.printf("Weather adjustment: %.3f L%n", weatherFuel);
		report.printf("Road adjustment: %+.3f L%n", roadFuel);
		report.printf("AC adjustment: %.3f L%n", acFuel);
		report.printf("Luggage adjustment: %.3f L%n", luggageFuel);
		report.printf("Traffic light adjustment: %.3f L%n", trafficFuel);
		report.printf("Stop sign adjustment: %.3f L%n", stopFuel);
		report.printf("Total fuel needed: %.2f L%n", totalFuel);
		report.println();
		report.println("Price comparison (CAD/L)");
		report.printf("%s: Regular %.3f, Premium %.3f%n",
		        firstStation.getName(),
		        firstStation.getRegularPrice(),
		        firstStation.getPremiumPrice());
		report.printf("%s: Regular %.3f, Premium %.3f%n",
		        secondStation.getName(),
		        secondStation.getRegularPrice(),
		        secondStation.getPremiumPrice());
		report.println("Selected station: " + bestStation.getName());
		report.println("Fuel grade: " + selectedCar.getFuelGrade());
		report.printf("Price: CAD %.3f/L%n", bestPrice);
		report.printf("Estimated trip cost: CAD %.2f%n", tripCost);
		report.printf("Budget: CAD %.2f%n", budget);
		report.println("Budget sufficient: " + budgetEnough);
		report.printf("Fuel affordable with budget: %.2f L%n", affordableFuel);

		if (budgetEnough) {
		    report.printf("Remaining budget: CAD %.2f%n", budget - tripCost);
		} else {
		    report.printf("Additional money needed: CAD %.2f%n", tripCost - budget);
		}

		report.close();
		scan.close();

		System.out.println("Report written to ConsumptionReport_YanN.txt");
		}
	
	public static double calculatePassengerFuel(double baseFuel, int passengers) {
		return baseFuel * passengers * 0.02;
	}
	
	public static double calculateWeatherFuel(double baseFuel, int weatherChoice) {
		if (weatherChoice == 1) {
			return 0;
		}
		else if (weatherChoice == 2) {
			return baseFuel * 0.05;
		}
		else {
			return baseFuel * 0.10;
		}
	}
	
	public static double calculateRoadFuel(double baseFuel, int roadChoice) {
		if (roadChoice == 1) {
			return 0;
		}
		else if (roadChoice == 2) {
			return baseFuel * 0.15;
		}
		else if (roadChoice == 3) {
			return baseFuel * 0.10;
		}
		else {
			return baseFuel * -0.05;
		}
	}
	
	public static double calculateAcFuel(double baseFuel, boolean acOn) {
		if (acOn) {
			return baseFuel * 0.05;
		}
		else {
			return 0;
		}
	}
	
	public static double calculateLuggageFuel(double baseFuel, double luggageWeight) {
	    return baseFuel * (luggageWeight / 50.0) * 0.01;
	}
	
	
}
