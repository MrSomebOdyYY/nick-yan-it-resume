
public class City {
	private String name;
	private String country;
		
	public City(String cityName, String countryName ) {
		name = cityName;
		country = countryName;
	}
	
	public String getName() {
		return name;
	}
	
	public String getCountry() {
		return country;
	}
}